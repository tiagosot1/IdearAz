 <div class="content_middle">
   	  <div class="container">
   	    <div class="content_middle_box">
          <div class="top_grid">
          
          
   			<div class="col-md-3 index-grids">
   			  <div class="grid1">
   				<div class="view view-first">
                  <div class="index_img"><img src="<?php echo base_url('resources/images/pic1.jpg');?>" class="img-responsive" alt=""/></div>
   				    <div class="sale">$2.980</div>
   			          <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="<?php echo base_url('resources/images/star.png');?>" alt=""/></li>
                        	<li class="set"><img src="<?php echo base_url('resources/images/set.png');?>" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                       </div>
                   </div> 
                   <i class="home"></i>
   				 <div class="inner_wrap">
   				 	<h3>Lorem Ipsum is simply dummy text</h3>
   				 	<ul class="star1">
   				 	  <h4 class="green">Vision Agency</h4>
   				 	  <li><a href="#"> <img src="<?php echo base_url('resources/images/star1.png');?>" alt="">(236)</a></li>
   				 	</ul>
   				 </div>
   			   </div>
   			</div>
            
            
   			<div class="col-md-3 index-grids">
   			  <div class="grid1">
   				<div class="view view-first">
                  <div class="index_img1"><img src="<?php echo base_url('resources/images/pic6.jpg');?>" class="img-responsive" alt=""/></div>
   				     <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="<?php echo base_url('resources/images/star.png');?>" alt=""/></li>
                        	<li class="set"><img src="<?php echo base_url('resources/images/set.png');?>" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                 <i class="home"> </i>
   				 <div class="inner_wrap">
   				 	<h3>Lorem Ipsum is simply dummy text</h3>
   				 	<ul class="star1">
   				 	  <h4 class="yellow">Vision Agency</h4>
   				 	  <li><a href="#"> <img src="<?php echo base_url('resources/images/star2.png');?>" alt="">(136)</a></li>
   				 	</ul>
   				 </div>
   			   </div>
   			</div>
            
            
   			<div class="col-md-3 index-grids">
   			  <div class="grid1">
   				<div class="view view-first">
                  <div class="index_img2"><img src="<?php echo base_url('resources/images/pic2.jpg');?>" class="img-responsive" alt=""/></div>
   				     <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="<?php echo base_url('resources/images/star.png');?>" alt=""/></li>
                        	<li class="set"><img src="<?php echo base_url('resources/images/set.png');?>" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                 <i class="home"> </i>
   				 <div class="inner_wrap">
   				 	<h3>Lorem Ipsum is simply dummy text</h3>
   				 	<ul class="star1">
   				 	  <h4 class="blue">Vision Agency</h4>
   				 	  <li><a href="#"> <img src="<?php echo base_url('resources/images/star2.png');?>" alt="">(136)</a></li>
   				 	</ul>
   				 </div>
   			   </div>
   			</div>
            
            
   			<div class="col-md-3 index-grids">
   			  <div class="grid1">
   				<div class="view view-first">
                  <div class="index_img"><img src="<?php echo base_url('resources/images/pic3.jpg');?>" class="img-responsive" alt=""/></div>
   				     <div class="sale">$2.980</div>
   			          <div class="mask">
                      <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                        	<li class="star"><img src="<?php echo base_url('resources/images/star.png');?>" alt=""/></li>
                        	<li class="set"><img src="<?php echo base_url('resources/images/set.png');?>" alt=""/></li>
                        	<div class="clearfix"> </div>
                        </ul>
                      </div>
                  </div> 
                  <i class="home"></i>
   				  <div class="inner_wrap">
   				 	<h3>Lorem Ipsum is simply dummy text</h3>
   				 	<ul class="star1">
   				 	  <h4 class="green">Vision Agency</h4>
   				 	  <li><a href="#"> <img src="<?php echo base_url('resources/images/star1.png');?>" alt="">(236)</a></li>
   				 	</ul>
   				  </div>
   			   </div>
   			</div>
   			<div class="clearfix"> </div>
   		
   	   			 
   		  	  </div>
   		  </div>
   	  </div>
   </div>
   