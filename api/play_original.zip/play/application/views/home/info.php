 
   <div class="content_top">
   	  <div class="container">
   		<div class="col-md-4 bottom_nav">
   		   <div class="content_menu">
				<ul>
					<li class="active"><a href="<?php echo base_url('home');?>">JOGUE VIDEO GAME, GANHE DINHEIRO</a></li> 
					
				</ul>
			</div>
		</div>
		
		<div class="col-md-4 filter_grid" style="float:right">
			<ul class="filter">
			
			</ul>
		</div>
   	</div>
   </div>