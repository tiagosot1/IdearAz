<!doctype html>

<html>

<head>

<meta charset="utf-8">

<title>Play Cash</title>

</head>



<body>

<div style=" margin:0% 0% 0% 25%">

<img src="<?php echo base_url('resources/images/desenvolvimento.jpg');?>" width="640" height="auto" alt=""/>

</div>

</body>

</html>



