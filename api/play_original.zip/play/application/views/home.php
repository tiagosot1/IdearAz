

<?php include('includes/head.php'); ?>
<body>
<?php include('includes/header.php'); ?>
<?php include('home/slider.php'); ?>
<?php include('home/info.php'); ?>
<?php include('home/jogos.php'); ?>
<?php include('includes/footer.php'); ?>