
<!DOCTYPE HTML>
<html lang="pt-BR">
<head>
<title>Play Cash </title>
<link href="<?php echo base_url('resources/css/bootstrap.css');?>" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url('resources/css/bootstrap-datepicker.min.css');?>" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Custom Theme files -->
<link href="<?php echo base_url('resources/css/style.css');?>" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="video Games, videogames, video game tournaments, cash prize tournaments, madden 25, nba2k, ps4, xbox one, xbox live tournaments, playstation 3, psp, ps3, xbox 360"  />
 <!-- Alterando a cor da Barra de Endereço do Chrome no Android -->
 <meta name="theme-color" content="#1a9b7c">


<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="<?php echo base_url('resources/js/jquery-1.11.1.min.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('resources/js/login.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('resources/js/bootstrap-datepicker.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('resources/js/bootstrap-datepicker.pt-BR.min.js');?>"></script>
<script src="<?php echo base_url('resources/js/jquery.easydropdown.js');?>"></script>

<!--Animation--><strong></strong>
<script src="<?php echo base_url('resources/js/wow.min.js');?>"></script>
<link href="<?php echo base_url('resources/css/animate.css');?>" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
</head>