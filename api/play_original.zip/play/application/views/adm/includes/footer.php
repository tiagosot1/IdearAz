 <footer class="main-footer">
    
    <strong>Copyright &copy; 2014-2016 <a href="http://playcash.com.br/">Play Cash</a>.</strong> All rights
    reserved.
  </footer>

 

</div>
<!-- ./wrapper -->