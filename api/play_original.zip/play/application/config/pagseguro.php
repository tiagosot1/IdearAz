<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['pagseguroAccount'] = 'tiagocdc2008@gmail.com'; // email de acesso ao painel do pagseguro.
//$config['pagseguroToken'] = '698F0C36118745FA85D5CD49E1EE367B'; // token do pagseguro
$config['pagseguroToken'] = '5EE76A162E704510AD0E8AC2E2A29796'; // token do pagseguro de teste
