For information about action hooks, consult the documentation:

http://openshift.github.io/documentation/oo_user_guide.html#action-hooks
